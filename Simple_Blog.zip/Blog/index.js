import express from "express"
import bodyParser from "body-parser";
const app = express()
const port = 3000

app.use(bodyParser.urlencoded({ extended: true}))

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
app.get("/",(req,res)=>{
  res.render("homepage.ejs")
});
app.post("/content",(req,res)=>{
  var name = req.body["fname"]
  var content = req.body["cont"]
  res.render("content.ejs",{name: name,content : content});
});

/*
app.get("/about",(req,res)=>{
  res.render("about.ejs")
});
app.get("/contact",(req,res)=>{
  res.render("contact.ejs")
});
*/
